package com.decisionbrain.optimserver.worker.task;

import com.decisionbrain.optimserver.common.parameter.Parameter;
import com.decisionbrain.optimserver.worker.Log4jInfoStream;

import com.decisionbrain.optimserver.worker.api.ExecutionContext;
import com.decisionbrain.optimserver.worker.api.Task;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.util.ArrayBuilders;
import com.gams.api.*;
import java.io.*;

import java.util.logging.Logger;
import java.util.zip.*;


public class GamsTask implements Task {
    static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private static Logger LOGGER = Logger.getLogger(GamsTask.class.getName());

    private File newFile(File destinationDir, ZipEntry zipEntry) throws IOException {
        File destFile = new File(destinationDir, zipEntry.getName());

        String destDirPath = destinationDir.getCanonicalPath();
        String destFilePath = destFile.getCanonicalPath();

        if (!destFilePath.startsWith(destDirPath + File.separator)) {
            throw new IOException("Entry is outside of the target dir: " + zipEntry.getName());
        }
        return destFile;
    }

    private void unzippingFromBinary(byte[] bytes, String toPath) throws IOException{
        File destDir = new File(toPath);
        byte[] buffer = new byte[1024];
        ByteArrayInputStream bas = new ByteArrayInputStream(bytes);
        ZipInputStream zis = new ZipInputStream(bas);
        ZipEntry zipEntry = zis.getNextEntry();
        while (zipEntry != null) {
            File newFile = newFile(destDir, zipEntry);
            FileOutputStream fos = new FileOutputStream(newFile);
            int len;
            while ((len = zis.read(buffer)) > 0) {
                fos.write(buffer, 0, len);
            }
            fos.close();
            zipEntry = zis.getNextEntry();
        }
        zis.closeEntry();
        zis.close();
    }

    private byte[] zippingToBinary(String dirPath) throws IOException{
        File fromFile = new File(dirPath);
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ZipOutputStream zipOut = new ZipOutputStream(baos);
        File[] inputFiles = fromFile.listFiles();
        if(inputFiles == null) {
            System.out.println("Cannot find the files");
            return null;
        }
        for (File srcFile : inputFiles) {
            FileInputStream fis = new FileInputStream(srcFile);
            ZipEntry zipEntry = new ZipEntry(srcFile.getName());
            zipOut.putNextEntry(zipEntry);
            byte[] bytes = new byte[1024];
            int length;
            while((length = fis.read(bytes)) >= 0) {
                zipOut.write(bytes, 0, length);
            }
            fis.close();
        }
        zipOut.close();
        return baos.toByteArray();
    }

    @Override
    public void execute(Parameter input, Parameter output, ExecutionContext context) {
        GAMSWorkspace ws = new GAMSWorkspace();
        byte[] inputBytes = input.get("model");
        File gfile = new File(ws.workingDirectory() + GAMSGlobals.FILE_SEPARATOR + "mainModel.gms");
        try {
            PrintWriter gout = new PrintWriter(gfile);
            String jobString = new String(inputBytes);
            gout.println(jobString);
            gout.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        byte[] dataBytes = input.get("data");
        try {
            unzippingFromBinary(dataBytes, ws.workingDirectory());
        } catch (IOException e) {
            System.out.println("Error while reading data: No input data or not a zipped input");
            e.printStackTrace();
        }

        GAMSOptions opt = ws.addOptions();
        // check if license.txt is in working directory
        // licence file name is supposed to be "gamslice.txt"
        String licFilePath = ws.workingDirectory() + GAMSGlobals.FILE_SEPARATOR + "gamslice.txt";
        File licFile = new File(licFilePath);
        if (licFile.exists()) {
            opt.setLicense(licFilePath);
            context.notifyMessage("GAMS licence provided.");
        } else {
            context.notifyMessage("No GAMS licence found.");
        }

        //check if gams.opt is in working directory
        String optFilePath = ws.workingDirectory() + GAMSGlobals.FILE_SEPARATOR + "gams.opt";
        File optFile = new File(optFilePath);
        if (optFile.exists() ) {
            opt.readFromStr("pf=gams.opt");
            context.notifyMessage("No gams.opt file found.");
        }else{
            context.notifyMessage("gams.opt file provided.");
        }

        // create Log for Clients log output windows and main.log for download, identically
        FileOutputStream fileOutputStream = null;
        final String logPath = ws.workingDirectory() + GAMSGlobals.FILE_SEPARATOR + "mainModel.log";
        try {
            fileOutputStream = new FileOutputStream(logPath);
        } catch (FileNotFoundException e) {
            File file = new File(logPath);
            try {
                if(file.createNewFile()){
                    fileOutputStream = new FileOutputStream(logPath);
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
        }

        Log4jInfoStream mos = new Log4jInfoStream();
        if(fileOutputStream != null){
            mos.addOutputStream(fileOutputStream);
        }else {
            System.out.println("File could not be created, see system output message:\n ");
        }
        mos.addOutputStream(System.err);
        PrintStream ps = new PrintStream(mos);

        // create GAMSJob
        GAMSJob job = ws.addJobFromFile("mainModel.gms");
        opt.setExecMode(GAMSOptions.EExecMode.EchoAndPutOnlyToWorkdir);
            
        // run the GAMSJob
        try {
            job.run(opt, ps);
        } catch (GAMSException ex) {
            ex.printStackTrace();
        } catch (Exception ex){
            ex.printStackTrace();
        } finally{
            try{
                if(fileOutputStream != null)
                    fileOutputStream.close();
            }catch (IOException e){
                e.printStackTrace();
            }
        }

        // zip all files in the working directory and return as results in binary format
        byte[] zipf = new byte[0];
        try {
            zipf = zippingToBinary( ws.workingDirectory() + GAMSGlobals.FILE_SEPARATOR);
        } catch (IOException e) {
            e.printStackTrace();
        }
        // export zip file (binary) to client output
        output.emit("zipresults.zip", zipf);
    }
}
