package com.decisionbrain.optimserver.worker;

import com.decisionbrain.optimserver.worker.api.EnableOptimServerWorker;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@EnableOptimServerWorker
@SpringBootApplication
public class GamsWorker {
    public static void main(String[] args) {
        SpringApplication.run(GamsWorker.class, args);
    }
}
