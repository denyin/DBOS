package com.decisionbrain.optimserver.worker;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Vector;

public class Log4jInfoStream extends OutputStream {
    private static final Logger LOGGER = LoggerFactory.getLogger(Log4jInfoStream.class);
    private StringBuilder builder;
    private Vector<OutputStream> m_streams;
    public Log4jInfoStream() {
        builder = new StringBuilder();
    }

    @Override
    public void write(int b) throws IOException{
        char c = (char)b;
        builder.append(c);

        if(c == '\n'){
            LOGGER.info(builder.toString());
            builder = new StringBuilder();
        }

        Enumeration e = getOutputStreams ();
        if (e == null)
            return;
        IOException ioe = null;
        while (e.hasMoreElements ())
        {
            try
            {
                ((OutputStream)e.nextElement ()).write (b);
            }
            catch (IOException exc)
            {
                ioe = exc;
            }
        }
        if (ioe != null)
            throw ioe;
    }

    public void addOutputStream (OutputStream os)
    {
        if (os == null)
            return;
        if (m_streams == null)
            m_streams = new Vector<> ();
        m_streams.addElement (os);
    }

    public Enumeration getOutputStreams ()
    {
        if (m_streams != null)
            return m_streams.elements ();
        return null;
    }

    public void close () throws IOException
    {
        Enumeration e = getOutputStreams ();
        if (e == null)
            return;
        IOException ioe = null;
        while (e.hasMoreElements ())
        {
            try
            {
                ((OutputStream)e.nextElement ()).close ();
            }
            catch (IOException exc)
            {
                ioe = exc;
            }
        }
        if (ioe != null)
            throw ioe;
    }

    public void flush () throws IOException
    {
        Enumeration e = getOutputStreams ();
        if (e == null)
            return;
        IOException ioe = null;
        while (e.hasMoreElements ())
        {
            try
            {
                ((OutputStream)e.nextElement ()).flush ();
            }
            catch (IOException exc)
            {
                ioe = exc;
            }
        }
        if (ioe != null)
            throw ioe;
    }
}