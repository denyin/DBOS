This project is a GAMSWorker used for DBOS. To be able to build this project, you will need:
 - the gradle build tool (https://gradle.org/install/),
 - A GAMS installation (version 28.2.0)
 - (and credentials to access the DecisionBrain Maven repository (Nexus).)

Follow the steps in order to build the jar file for the GAMSWorker, create the GAMSWorker Docker image 
and deploy the DBOS along with the GAMSWorker itself:
1) cd [GAMS sysdir]\apifiles\Java\api
2) cp *.dll [GamsWorker-DBOS-2.2.3]\libs
3) cp GAMSJavaAPI.jar [GamsWorker-DBOS-2.2.3]\libs
4) cd [GamsWorker-DBOS-2.2.3]
5) configure the gradle.properties (specification of credentails)
6) gradlew.bat build
7) docker build -t gams-worker:28.2.0 .
8) cd deployment
9) docker-compose up -d
10) docker-compose -f docker-compose-workers.yml up gams-worker





 



